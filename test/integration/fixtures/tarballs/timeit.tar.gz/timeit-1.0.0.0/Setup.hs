module Main where
import Distribution.Simple
main = defaultMain
