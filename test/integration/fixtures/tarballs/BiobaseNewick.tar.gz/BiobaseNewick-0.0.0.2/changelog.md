0.0.0.2
-------

- removed most upper bounds

0.0.0.1
-------

- initial creation
- travis-ci integration
- simple test framework
- depends on ForestStructures for conversion into efficient static forest
